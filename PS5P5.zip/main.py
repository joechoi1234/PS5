
counter = 0

response = input("Do you want to calculate total price Yes or No? ")

while response == "Yes":
  quantity = float(input("Enter quantity of item: "))
  price = float(input("Enter price of item: "))
  extprice = quantity * price
  if(extprice > 10000):
    discperc = .25
  else:
    discperc = .10
  discount = extprice * discperc
  counter = counter + discount
  total = extprice - discount
 
  
  print("Extended price: " , extprice)
  print("Total price: " , total)
  print("Discount: " , discount)
  
  response = input("Do you want to calculate total price Yes or No? ")
  print("Total discount: " , counter)