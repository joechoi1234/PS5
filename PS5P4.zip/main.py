
counter = 0
totalpay = 0.0

response = input("Do you want to calculate gross pay Yes or No?: ")

while response == "Yes":
  counter = counter + 1
  lastname = input("Enter student last name: ")
  rate = float(input("Enter pay rate: "))
  hours = float(input("Enter hours worked: "))
  if(hours > 40):
    pay = (40 * rate) + ((hours - 40)*(rate * 1.5))
  else:
    pay = (40 * rate)
  print("Last name: " , lastname)
  print("Gross pay: " , pay)
  totalpay = totalpay + pay
  response = input("Want to calculate gross pay Yes or No?: ")

avgpay = totalpay / counter
print("Number of students: " , counter)
print("Average pay: " , avgpay)
    

  