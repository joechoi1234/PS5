
counter = 0

response = input("Do you want to calculate average score Yes or No?: ")

while response == "Yes":
  counter = counter + 1
  lastname = input("Enter student last name: ")
  score1 = float(input("Enter score #1: "))
  score2 = float(input("Enter score #2: "))
  avg = (score1 + score2) / 2
  print(lastname , "has average of " , avg)
  response = input("Want to calculate average score Yes or No: ")

print("Number of students: " , counter)
  




